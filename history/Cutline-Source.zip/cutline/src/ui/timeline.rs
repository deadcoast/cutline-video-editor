use super::theme;
use cutline::{
    media::probe::Media,
    model::{Edit, Trim, timecode},
};
use eframe::egui::{self, Align2, Color32, FontId, Pos2, Rect, Sense, Stroke, StrokeKind, Vec2};

#[derive(Clone, Copy)]
enum Part {
    Head,
    Tail,
    Playhead,
    Selection,
}
struct Drag {
    part: Part,
    before: Edit,
    origin: f64,
}
pub struct Timeline {
    pub zoom: f64,
    pub offset: f64,
    drag: Option<Drag>,
}
impl Default for Timeline {
    fn default() -> Self {
        Self {
            zoom: 1.0,
            offset: 0.0,
            drag: None,
        }
    }
}
#[derive(Default)]
pub struct Response {
    pub seek: Option<(f64, bool)>,
    pub committed: Option<Edit>,
    pub editing: bool,
}

impl Timeline {
    pub fn fit(&mut self) {
        self.zoom = 1.0;
        self.offset = 0.0;
    }
    pub fn zoom_at(&mut self, factor: f64, position: f64, duration: f64) {
        let old_span = duration / self.zoom;
        let fraction = ((position - self.offset) / old_span).clamp(0.0, 1.0);
        self.zoom = (self.zoom * factor).clamp(1.0, 1024.0);
        let span = duration / self.zoom;
        self.offset = (position - span * fraction).clamp(0.0, (duration - span).max(0.0));
    }
    pub fn show(
        &mut self,
        ui: &mut egui::Ui,
        media: &Media,
        edit: &mut Edit,
        position: f64,
    ) -> Response {
        let mut result = Response::default();
        let (rect, response) = ui.allocate_exact_size(
            Vec2::new(ui.available_width(), 58.0),
            Sense::click_and_drag(),
        );
        response.widget_info(|| {
            egui::WidgetInfo::labeled(
                egui::WidgetType::Slider,
                true,
                "Trim timeline. I sets the start; O sets the end. Open Trim for numeric entry.",
            )
        });
        let rail = Rect::from_min_max(
            rect.min + egui::vec2(12.0, 22.0),
            rect.max - egui::vec2(12.0, 8.0),
        );
        let span = media.duration / self.zoom;
        self.offset = self.offset.clamp(0.0, (media.duration - span).max(0.0));
        let time_to_x = |t: f64| rail.left() + ((t - self.offset) / span) as f32 * rail.width();
        let x_to_time = |x: f32| {
            ((x - rail.left()) as f64 / rail.width() as f64 * span + self.offset)
                .clamp(0.0, media.duration)
        };
        let head = time_to_x(edit.trim.start);
        let tail = time_to_x(edit.trim.end);
        if response.drag_started()
            && let Some(pointer) = ui.input(|i| i.pointer.press_origin())
        {
            let part = if (pointer.x - head).abs() < 13.0 {
                Part::Head
            } else if (pointer.x - tail).abs() < 13.0 {
                Part::Tail
            } else if ui.input(|i| i.modifiers.shift) && pointer.x >= head && pointer.x <= tail {
                Part::Selection
            } else {
                Part::Playhead
            };
            self.drag = Some(Drag {
                part,
                before: edit.clone(),
                origin: x_to_time(pointer.x),
            });
        }
        if let Some(pointer) = response.interact_pointer_pos() {
            if let Some(drag) = &self.drag {
                let target = media.snap(x_to_time(pointer.x));
                let minimum = media.rate.frame_seconds().min(media.duration);
                match drag.part {
                    Part::Head => {
                        edit.trim.start = target.min(edit.trim.end - minimum).max(0.0);
                        result.seek = Some((edit.trim.start, false));
                    }
                    Part::Tail => {
                        edit.trim.end = target.max(edit.trim.start + minimum).min(media.duration);
                        result.seek = Some(((edit.trim.end - minimum).max(edit.trim.start), false));
                    }
                    Part::Playhead => result.seek = Some((target, false)),
                    Part::Selection => {
                        let length = drag.before.trim.duration();
                        let start = media
                            .snap(drag.before.trim.start + target - drag.origin)
                            .clamp(0.0, media.duration - length);
                        edit.trim = Trim {
                            start,
                            end: start + length,
                        };
                        result.seek = Some((start, false));
                    }
                }
            } else if response.clicked() {
                result.seek = Some((media.snap(x_to_time(pointer.x)), true));
            }
        }
        if response.drag_stopped()
            && let Some(drag) = self.drag.take()
        {
            result.committed = Some(drag.before);
            let target = match drag.part {
                Part::Head | Part::Selection => edit.trim.start,
                Part::Tail => (edit.trim.end - media.rate.frame_seconds()).max(edit.trim.start),
                Part::Playhead => response
                    .interact_pointer_pos()
                    .map(|p| media.snap(x_to_time(p.x)))
                    .unwrap_or(position),
            };
            result.seek = Some((target, true));
        }
        result.editing = self.drag.is_some();
        if response.has_focus() && ui.input(|i| i.key_pressed(egui::Key::ArrowRight)) {
            result.seek = Some((
                (position + media.rate.frame_seconds()).min(media.duration),
                true,
            ));
        }
        if response.has_focus() && ui.input(|i| i.key_pressed(egui::Key::ArrowLeft)) {
            result.seek = Some(((position - media.rate.frame_seconds()).max(0.0), true));
        }
        let p = ui.painter_at(rect);
        p.rect_filled(rail, 2.0, Color32::from_rgb(46, 51, 57));
        let selected = Rect::from_min_max(
            Pos2::new(time_to_x(edit.trim.start).max(rail.left()), rail.top()),
            Pos2::new(time_to_x(edit.trim.end).min(rail.right()), rail.bottom()),
        );
        if selected.is_positive() {
            p.rect_filled(selected, 0.0, theme::TRIM.gamma_multiply(0.18));
            p.line_segment(
                [selected.left_top(), selected.right_top()],
                Stroke::new(1.0_f32, theme::TRIM),
            );
            p.line_segment(
                [selected.left_bottom(), selected.right_bottom()],
                Stroke::new(1.0_f32, theme::TRIM),
            );
        }
        for i in 0..=40 {
            let x = rail.left() + rail.width() * i as f32 / 40.0;
            p.line_segment(
                [
                    Pos2::new(x, rail.center().y - 2.0),
                    Pos2::new(x, rail.center().y + if i % 5 == 0 { 4.0 } else { 2.0 }),
                ],
                Stroke::new(1.0_f32, theme::MUTED.gamma_multiply(0.35)),
            );
        }
        for (time, is_head) in [(edit.trim.start, true), (edit.trim.end, false)] {
            let x = time_to_x(time);
            if x >= rail.left() - 1.0 && x <= rail.right() + 1.0 {
                let handle = Rect::from_center_size(
                    Pos2::new(x, rail.center().y),
                    egui::vec2(18.0, rail.height() + 8.0),
                );
                p.rect_filled(handle, 2.0, theme::TRIM);
                let direction = if is_head { 1.0 } else { -1.0 };
                for y in [-7.0, 7.0] {
                    p.line_segment(
                        [
                            Pos2::new(x - direction * 2.0, rail.center().y + y),
                            Pos2::new(x + direction * 3.0, rail.center().y + y),
                        ],
                        Stroke::new(1.5_f32, theme::CANVAS),
                    );
                }
                p.line_segment(
                    [
                        Pos2::new(x - direction * 2.0, rail.center().y - 7.0),
                        Pos2::new(x - direction * 2.0, rail.center().y + 7.0),
                    ],
                    Stroke::new(1.5_f32, theme::CANVAS),
                );
            }
        }
        let x = time_to_x(position);
        if rail.x_range().contains(x) {
            p.line_segment(
                [
                    Pos2::new(x, rail.top() - 7.0),
                    Pos2::new(x, rail.bottom() + 6.0),
                ],
                Stroke::new(1.5_f32, theme::INK),
            );
            p.circle_filled(Pos2::new(x, rail.top() - 8.0), 3.0, theme::INK);
        }
        p.text(
            Pos2::new(rail.left(), rect.top()),
            Align2::LEFT_TOP,
            format!("IN  {}", timecode(edit.trim.start)),
            FontId::monospace(11.0),
            theme::TRIM,
        );
        p.text(
            Pos2::new(rail.right(), rect.top()),
            Align2::RIGHT_TOP,
            format!("{}  OUT", timecode(edit.trim.end)),
            FontId::monospace(11.0),
            theme::TRIM,
        );
        if rail.width() > 420.0 {
            p.text(
                Pos2::new(rail.center().x, rect.top()),
                Align2::CENTER_TOP,
                format!("{} selected", timecode(edit.trim.duration())),
                FontId::monospace(11.0),
                theme::MUTED,
            );
        }
        if response.has_focus() {
            p.rect_stroke(
                rect,
                3.0,
                Stroke::new(1.0_f32, theme::CROP),
                StrokeKind::Inside,
            );
        }
        if response.hovered() {
            if let Some(pos) = ui.input(|i| i.pointer.hover_pos()) {
                let handle = (pos.x - head).abs() < 13.0 || (pos.x - tail).abs() < 13.0;
                ui.ctx().set_cursor_icon(if handle {
                    egui::CursorIcon::ResizeHorizontal
                } else {
                    egui::CursorIcon::PointingHand
                });
            }
            let scroll = ui.input(|i| i.smooth_scroll_delta.y);
            if scroll.abs() > 0.0 {
                if ui.input(|i| i.modifiers.ctrl) {
                    self.zoom_at((scroll as f64 * 0.01).exp(), position, media.duration);
                } else {
                    self.offset = (self.offset - scroll as f64 / 500.0 * span)
                        .clamp(0.0, (media.duration - span).max(0.0));
                }
            }
        }
        response.on_hover_text("Drag the brackets to trim · Click to seek · Shift-drag to move the selection · Ctrl+wheel to zoom");
        result
    }
}
